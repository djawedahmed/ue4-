<?php

require_once '../inc/template.class.php';
require_once '../inc/config.php';
require_once '../inc/functions.php';

if ((empty($_SERVER['HTTP_X_REQUESTED_WITH']) or strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) != 'xmlhttprequest') or empty($_POST)) {/* Detect AJAX and POST request */
    exit('Unauthorized Acces');
}
session_start();

/* Check Login form submitted */
if (!empty($_POST) && $_POST['Action'] == 'login_form') {
    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];

    $email = safe_input($con, $_POST['Email']);
    $password = safe_input($con, $_POST['Password']);

    /* Server side PHP input validation */
    if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
        $Return['error'] = 'Please enter a valid Email address.';
    } elseif ($password === '') {
        $Return['error'] = 'Please enter Password.';
    }
    if ($Return['error'] != '') {
        output($Return);
    }

    /* Check Email and Password existence in DB */
    $result = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='".md5($password)."' LIMIT 1");

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);

        /* Success: Set session variables and redirect to Protected page */
        $_SESSION['Data'] = ['id' => $row['id'], 'fname' => $row['name'], 'lname' => $row['email']];
        $Return['result'] = $_SESSION['Data'];
    } else {
        /* Unsuccessful attempt: Set error message */
        $Return['error'] = 'Invalid Login Credential.';
    }
    /* Return */

    output($Return);
}

if (!empty($_POST) && $_POST['Action'] == 'characters_form') {
    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];
    $character = safe_input($con, $_POST['character']);
    $table_id = safe_input($con, $_POST['table_id']);

    if (!empty($_POST['tags'])) {
        $tags = json_encode($_POST['tags']);
    } else {
        $tags = '';
    }

    $Mode = safe_input($con, $_POST['mode']);
    $ID = safe_input($con, $_POST['id']);
    $table = safe_input($con, $_POST['table']);

    if ($Mode == 'Add') {
        $sql = "INSERT INTO `characters` (`character_name`,`tags`,table_id) VALUE ('$character','$tags',$table_id);";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Added successfully';
        } else {
            $Return['error'] = 'error while adding record';

            $con->error;
        }
    }

    if ($Mode == 'edit') {
        $sql = "UPDATE characters SET  `character_name` = '$character' , tags = '$tags',table_id = $table_id Where id= $ID;";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Edited successfully';
        } else {
            $Return['error'] = 'error while editing record';
            $con->error;
        }
    }

    # return
    output($Return);
}

if (!empty($_POST) && $_POST['Action'] == 'filters_form') {
    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];
    $filter_name = safe_input($con, $_POST['tag']);

    $Mode = safe_input($con, $_POST['mode']);
    $ID = safe_input($con, $_POST['id']);
    $table = safe_input($con, $_POST['table']);

    if ($Mode == 'Add') {
        $sql = "INSERT INTO `filters` (`id`, `filter_name`) VALUES (NULL, '$filter_name');";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Added successfully';
        } else {
            $Return['error'] = 'error while adding record';

            $con->error;
        }
    }

    if ($Mode == 'edit') {
        $sql = "UPDATE filters SET  `filter_name` = '$filter_name' Where id=$ID;";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Edited successfully';
        } else {
            $Return['error'] = 'error while editing record';
            $con->error;
        }
    }

    # return
    output($Return);
}

if (!empty($_POST) && $_POST['Action'] == 'character_data_form') {
    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];

    $character_id = safe_input($con, $_POST['character_id']);
    $category = safe_input($con, $_POST['category']);
    $item = safe_input($con, $_POST['item']);
    $data_index = safe_input($con, $_POST['data_index']);

    $Mode = safe_input($con, $_POST['mode']);
    $ID = safe_input($con, $_POST['id']);
    $table = safe_input($con, $_POST['table']);

    if ($Mode == 'Add') {
        # construct character_data array
        $data = ['category' => $category, 'item' => $item, 'img' => '', 'character_id' => $character_id];
        # get  stored character data from db and turn it to an array
        $All_Character_Data = json_decode(get_query_content("SELECT * FROM characters WHERE id = $character_id")['character_data'], true);
        # push data to array
        $All_Character_Data[] = $data;
        # make json format of new data
        $json_data = json_encode($All_Character_Data);

        $sql = "UPDATE   characters SET  character_data ='$json_data' WHERE id = $character_id;";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Added successfully';
        } else {
            $Return['error'] = 'error while adding record';

            $con->error;
        }
    }

    if ($Mode == 'edit') {
        # get  stored character data from db and turn it to an array
        $All_Character_Data = json_decode(get_query_content("SELECT * FROM characters WHERE id = $character_id")['character_data'], true);
        $All_Character_Data[$data_index]['item'] = $item;
        $All_Character_Data[$data_index]['category'] = $category;
        $All_Character_Data[$data_index]['character_id'] = $character_id;

        $json_data = json_encode($All_Character_Data);
        $sql = "UPDATE characters SET  character_data = '$json_data' WHERE characters.id =$character_id;";
        if ($con->query($sql) === true) {
            $Return['result'] = 'record Edited successfully';
        } else {
            $Return['error'] = 'error while editing record';
            echo $con->error;
        }
    }

    # return
    output($Return);
}

/* Delete From table on data base */
if (!empty($_POST) && $_POST['Action'] == 'delete_character_data') {
    $data_index = safe_input($con, $_POST['index']);
    $character_id = safe_input($con, $_POST['character_id']);

    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];

    # get  stored character data from db and turn it to an array
    $All_Character_Data = json_decode(get_query_content("SELECT * FROM characters WHERE id = $character_id")['character_data'], true);

    unset($All_Character_Data[$data_index]);

    $json_data = json_encode($All_Character_Data);

    $sql = "UPDATE characters SET  character_data = '$json_data' WHERE characters.id =$character_id;";

    if ($con->query($sql) === true) {
        $Return['result'] = 'record deleted successfully';
    } else {
        $Return['error'] = 'Error deleting record';
        $con->error;
    }
    output($Return);
}

/* Delete From table on data base */
if (!empty($_POST) && $_POST['Action'] == 'delete') {
    /* Define return | here result is used to return user data and error for error message */
    $Return = ['result' => '', 'error' => ''];

    $ID = safe_input($con, $_POST['id']);
    $table = safe_input($con, $_POST['table']);

    /* SQL statment for deleting record from database */

    $sql = "DELETE FROM $table WHERE id=$ID";

    if ($con->query($sql) === true) {
        $Return['result'] = 'record deleted successfully';
    } else {
        $Return['error'] = 'Error deleting record';
        $con->error;
    }
    output($Return);
}

# update general Settigns
if (!empty($_POST) && $_POST['Action'] == 'settings_form') {
    $Return = ['result' => '', 'error' => ''];

    $sql = "UPDATE website_settings SET  name = '{$_POST['name']}',title = '{$_POST['title']}',meta_description = '{$_POST['meta_description']}',fb_link = '{$_POST['fb_link']}',insta_link = '{$_POST['insta_link']}',tweeter_link = '{$_POST['tweeter_link']}',telegram_link = '{$_POST['telegram_link']}' ;";
    if ($con->query($sql) === true) {
        $Return['result'] = 'record Edited successfully';
    } else {
        $Return['error'] = 'error while editing record';
        echo $con->error;
    }

    output($Return);
}
# update admin info

if (!empty($_POST) && $_POST['Action'] == 'admin_form') {
    $Return = ['result' => '', 'error' => ''];
    $pass = md5($_POST['password']);
    $sql = "UPDATE users SET  fname = '{$_POST['fname']}',lname = '{$_POST['lname']}',email = '{$_POST['email']}',password = '{$pass}' WHERE id=3";
    if ($con->query($sql) === true) {
        $Return['result'] = 'record Edited successfully';
    } else {
        $Return['error'] = 'error while editing record';
        echo $con->error;
    }
    output($Return);
}

if (!empty($_POST) && $_POST['Action'] == 'Get_characters_data_by_id') {
    $table_id = safe_input($con, $_POST['table_id']);

    # return all characters  with html tr wrap
    $character_objs = '';
    $characters_data = get_query_contents("SELECT * FROM characters WHERE table_id = $table_id");

    foreach ($characters_data as $character) {
        $character_data_html = '';
        $character_datas = json_decode($character['character_data'], true);
        if ($character_datas !== null) {
            foreach ($character_datas as $key => $value) {
                $data_html = new HtmlPage();
                $data_html->load('templates/objects/character_tr_obj.html');
                $data_html->Process(array_merge(['c_id' => $key, 'json_data' => json_encode($value)], $value));
                $character_data_html .= $data_html->GetHtml();
            }
        }

        $characters_html = new HtmlPage();
        $characters_html->load('templates/objects/character_ftitle_tr_obj.html');
        $characters_html->Process(['character_data' => $character_data_html, 'id' => $character['id'], 'character_name' => $character['character_name'], 'json_data' => json_encode($character)]);
        $character_objs .= $characters_html->GetHtml();
    }

    exit($character_objs);
}

if (!empty($_POST) && $_POST['Action'] == 'Get_characters_by_id') {
    $table_id = safe_input($con, $_POST['table_id']);

    # return charachters data options
    $characters_options = '';

    $character_data = get_query_contents("SELECT * FROM characters WHERE table_id=$table_id");
    foreach ($character_data as $character) {
        $character_op_html = new HtmlPage();
        $character_op_html->load('templates/objects/character_op_obj.html');
        $character_op_html->Process($character);
        $characters_options .= $character_op_html->GetHtml();
    }

    exit($characters_options);
}

if (!empty($_POST) && $_POST['Action'] == 'Get_characters_by_role') {
    $table_id = safe_input($con, $_POST['table_id']);
    $role_data = safe_input($con, $_POST['table_id']);

    $role = safe_input($con, $_POST['role']);

    $character_class = new character();

    switch ($role) {
        case 'table':
            exit($character_class->$characters->CharacterList($table_id));
            break;
        case 'role1':
            break;

        default:
            # code...
            break;
    }
}
