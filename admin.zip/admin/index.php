<?php

session_start();

if (!isset($_SESSION['Data'])) {
    header('location:login.php');
}

include '../inc/template.class.php';
include '../inc/config.php';

// return tags data
$tags_inputs = '';

// return tables options  html
$tables_options = '';
$tables_options_data = get_query_contents('SELECT * FROM tables');
foreach ($tables_options_data as $table) {
    $tables_options_html = new HtmlPage();
    $tables_options_html->load('templates/objects/table_op_obj.html');
    $tables_options_html->Process($table);
    $tables_options .= $tables_options_html->GetHtml();
}

$tags_data = get_query_contents('SELECT * FROM filters');
foreach ($tags_data as $tag) {
    $tags_input_html = new HtmlPage();
    $tags_input_html->load('templates/objects/tags_input.html');
    $tags_input_html->Process($tag);
    $tags_inputs .= $tags_input_html->GetHtml();
}



// return all characters  with html tr wrap
$character_objs = '';
$characters_data = get_query_contents('SELECT * FROM characters');

foreach ($characters_data as $character) {
    $character_data_html = '';
    $character_datas = json_decode($character['character_data'], true);
    if ($character_datas !== null) {
        foreach ($character_datas as $key => $value) {
            $data_html = new HtmlPage();
            $data_html->load('templates/objects/character_tr_obj.html');
            $data_html->Process(array_merge(['c_id' => $key, 'json_data' => json_encode($value)], $value));
            $character_data_html .= $data_html->GetHtml();
        }
    }

    $characters_html = new HtmlPage();
    $characters_html->load('templates/objects/character_ftitle_tr_obj.html');
    $characters_html->Process(['character_data' => $character_data_html, 'id' => $character['id'], 'character_name' => $character['character_name'], 'json_data' => json_encode($character)]);
    $character_objs .= $characters_html->GetHtml();
}

// output categories page to admin
$character_page = new HtmlPage();
$character_page->LoadHeader('templates/pages/header.html');
$character_page->LoadFooter('templates/pages/footer.html');
$character_page->Load('templates/pages/characters.html');
$character_page->Process([
    'title' => 'Realengine ',
    'filters' => $tags_inputs,
    'tables_options' => $tables_options,
]);
echo $character_page->GetHtml();
