<?php


session_start();
if (isset($_SESSION['Data'])) {
  header("location:/realengine/admin");
}
?>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MOBILE STORE ADMIN PANEL</title>
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/singin.css">

</head>

<body class="text-center">
  <main class="form-signin">
    <form action="submit.php" method="post" name="login_form" id="login_form">

      <img class="mb-4" src="../images/logo.png" alt="" width="250px">
      <div id="display_error"></div>
      <h1 class="h3 mb-3 fw-normal">Please sign in</h1>
      <div class="form-floating">
        <input class="form-control" id="floatingInput" type="email" name="Email" placeholder="email">
        <label for="floatingInput">Email address</label>
      </div>
      <div class="form-floating">
        <input type="password" class="form-control" id="floatingPassword" name="Password" placeholder="Password">
        <label for="floatingPassword">Password</label>
      </div>
      <div class="checkbox mb-3">
        <label>
          <input type="checkbox" value="remember-me"> Remember me
        </label>
      </div>
      <button class="w-100 btn btn-lg btn-primary" type="submit">Login</button>
      <p class="mt-5 mb-3 text-muted">&copy; 2017–2021</p>

    </form>
  </main>
</body>
<script src="../js/jquery-3.6.0.min.js"></script>
<script>
  $("#login_form, #registration_form").submit(function(e) {
    e.preventDefault();
    var obj = $(this),
      action = obj.attr('name'); /*Define variables*/
    $.ajax({
      type: "POST",
      url: e.target.action,
      data: obj.serialize() + "&Action=" + action,
      cache: false,
      success: function(RES) {
        console.log(RES)
        var RESPONSE = JSON.parse(RES);
        console.log(RESPONSE);
        if (RESPONSE.error != '') {
          $("#" + action + " #display_error").show().html(RESPONSE.error);
          alert(RESPONSE.error);
        } else {
          window.location.href = "/realengine/admin";
        }
      }
    });

  });
</script>

</html>