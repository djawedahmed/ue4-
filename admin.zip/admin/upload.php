<?php

require '../inc/functions.php';
require '../inc/config.php';

if (isset($_FILES['file']['type'])) {
    $Return = ['result' => '', 'error' => '', 'file_path' => ''];
    @$id = $_POST['id'];
    $directory = $_POST['directory'];
    @$file_name = $_POST['file_name'];

    $validextensions = ['jpeg', 'jpg', 'png'];
    $temporary = explode('.', $_FILES['file']['name']);
    $file_extension = end($temporary);
    if ((($_FILES['file']['type'] == 'image/png') || ($_FILES['file']['type'] == 'image/jpg') || ($_FILES['file']['type'] == 'image/jpeg')
    ) && ($_FILES['file']['size'] < 50000000) // Approx. 100kb files can be uploaded.
    && in_array($file_extension, $validextensions)
    ) {
        if ($_FILES['file']['error'] > 0) {
            $Return['error'] = $_FILES['file']['error'];
        } else {
            if (file_exists('../img/'.$_FILES['file']['name'])) {
                $Return['error'] = $_FILES['file']['name'].' already exists ';

                $image = 'img/'.$_FILES['file']['name'];

                if ($directory == 'character_a') {
                    $character_id = $_POST['character_id'];
                    sql_query("UPDATE character_a SET   image = '$image' Where id= $character_id");
                }
            } else {
                switch ($_FILES['file']['type']) {
                    case 'image/png':
                        $file_name = $file_name.'.png';
                        break;
                    case 'image/jpg':
                        $file_name = $file_name.'.jpg';
                        break;
                    case 'image/jpeg':
                        $file_name = $file_name.'.jpeg';
                        break;
                }

                $sourcePath = $_FILES['file']['tmp_name']; // Storing source path of the file in a variable
                $targetPath = '../img/'.$_FILES['file']['name']; // Target path where file is to be stored
                move_uploaded_file($sourcePath, $targetPath); // Moving Uploaded file

                $Return['result'] = 'Image Uploaded Successfully';
                $Return['file_path'] = str_replace('../', '', $targetPath);
                if ($directory == 'logo') {
                    sql_query("UPDATE website_settings SET   logo = '{$Return['file_path']}' Where id=1");
                } elseif ($directory == 'favico') {
                    sql_query("UPDATE website_settings SET   fav_ico = '{$Return['file_path']}' Where id=1");
                } else {
                    $character_id = $_POST['character_id'];
                    $data_index = $_POST['id'];
                    // get  stored character data from db and turn it to an array
                    $All_Character_Data = json_decode(get_query_content("SELECT * FROM characters WHERE id = $character_id")['character_data'], true);
                    $All_Character_Data[$data_index]['img'] = $Return['file_path'];
                    $json_data = json_encode($All_Character_Data);
                    sql_query("UPDATE characters SET   character_data = '$json_data' Where id=$character_id");
                }
                if ($directory == 'character_a') {
                    sql_query("UPDATE characters SET   image = '{$Return['file_path']}' Where id= $character_id");
                }

                // echo "<br/><b>File Name:</b> " . $_FILES["file"]["name"] . "<br>";
                // echo "<b>Type:</b> " . $_FILES["file"]["type"] . "<br>";
                // echo "<b>Size:</b> " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
                // echo "<b>Temp file:</b> " . $_FILES["file"]["tmp_name"] . "<br>";
            }
        }
    } else {
        if ($_FILES['file']['size'] < 30000000) {
            $Return['error'] = 'Invalid file Size';
        } else {
            $Return['error'] = 'Invalid file type';
        }
    }
    output($Return);
}
