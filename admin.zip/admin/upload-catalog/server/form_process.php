<?php
require_once('../../../inc/functions.php');
require_once('../../../inc/config.php');
/*
 * Ajax Multiple Image Uploader
 * https://github.com/tharindulucky/ajax-multi-image-uploader
 *
 * Copyright 2018, Tharindu Lakshitha
 * https://coderaweso.me
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 *
 * Use this file for stuff like DB operations
 *
 */

if (isset($_POST['submit'])) {
    $obj = new stdClass();
    foreach ($_POST['uploaded_image_name'] as $k => $v) {
        $obj->{$k} = $v;
    }

    $data  =  json_encode($obj);
    if (sql_query("UPDATE catalogs SET   catalog_pdf_file ='$data' Where id={$_POST['catalog_id']}") == true) {

        echo '<h4>Uploaded succesfuly</h4> <br> <h3><a href="/admin/?page=catalogs"> return to admin panel</a>"</h3>';
    } else {
        echo 'problem while uploading data to db';
    }
    //Save to DB
    //Do whatever you want

}
